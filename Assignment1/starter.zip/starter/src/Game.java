/**
 * Created by lindseyshorser on 2018-05-10.
 */

import java.util.ArrayList;

public class Game {

    private String id;
    private ArrayList players;

    public Game(String id){
    }

}
