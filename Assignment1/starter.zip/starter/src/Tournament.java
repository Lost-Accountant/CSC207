/**
 * Created by lindseyshorser on 2018-05-10.
 */
public class Tournament {

    public static void main(String[] args){

    }

}