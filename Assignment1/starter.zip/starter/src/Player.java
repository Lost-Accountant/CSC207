/**
 * Created by lindseyshorser on 2018-05-10.
 */

import java.util.ArrayList;

public class Player {

    private String name;
    private int rank;
    private ArrayList games;

    Player(String name, int rank){
    }

}
